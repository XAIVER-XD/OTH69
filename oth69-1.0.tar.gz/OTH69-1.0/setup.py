from setuptools import setup, Extension

setup(
    name='OTH69',
    version='1.0',
    ext_modules=[Extension('oth69', ['$HOME/OT/oth69/oth69.cpython-311.so'])],
)
